# Tonto
Like Tony Stark

Menu Python + Reconocimiento de Voz 

Now with voice

Last update: https://youtu.be/j2A64qr-JEM
